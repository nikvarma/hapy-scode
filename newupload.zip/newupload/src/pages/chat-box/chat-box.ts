import {
  Component,
  OnInit,
  AfterContentInit,
  ElementRef,
  ViewChild
} from "@angular/core";
import {
  IonicPage,
  NavController,
  NavParams,
  ViewController,
  ActionSheetController,
  PopoverController,
  ToastController,
  Content
} from "ionic-angular";

import { Storage } from "@ionic/storage";
import { Observable } from "rxjs";
import { AngularFireDatabase } from "angularfire2/database";
import { InitloadProvider, CallProvider } from "../../providers";
import { CallchatmessageProvider } from "../../providers/callchatmessage/callchatmessage";
import {
  MessageBox,
  MessageSendBy,
  MessageConnection
} from "../../models/index";

@IonicPage()
@Component({
  selector: "page-chat-box",
  templateUrl: "chat-box.html",
  providers: [CallProvider, CallchatmessageProvider]
})
export class ChatBoxPage implements OnInit, AfterContentInit {
  toId: string;
  userId: string;
  bgImage: string;
  messageId: string;
  toUserDetails = {};
  items: Observable<any[]>;
  textempty: boolean = true;
  messageList: Array<any> = [];
  messageTextBox: HTMLTextAreaElement;
  isLoad: boolean = true;

  @ViewChild(Content)
  ionContent: Content;
  @ViewChild("chatboxbody", { read: ElementRef })
  chatboxbody: ElementRef;
  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private storage: Storage,
    private viewCtrl: ViewController,
    private actionsheetCtrl: ActionSheetController,
    private popoverCtrl: PopoverController,
    private fdb: AngularFireDatabase,
    private initLoad: InitloadProvider,
    private call: CallProvider,
    private toast: ToastController,
    private callchatMessage: CallchatmessageProvider
  ) {}

  ionViewDidLoad() {}

  closeChatBox(): void {
    this.viewCtrl.dismiss();
  }

  shareThings(): void {
    this.actionsheetCtrl
      .create({
        cssClass: "action-sheet chatbox-share-things",
        buttons: [
          {
            icon: "pin",
            text: "Location",
            cssClass: "location-icon-color",
            handler: () => {}
          },
          {
            icon: "images",
            text: "Image",
            cssClass: "call-icon-color",
            handler: () => {}
          },
          {
            icon: "film",
            text: "Video",
            cssClass: "video-icon-color",
            handler: () => {}
          },
          {
            icon: "document",
            text: "Document",
            cssClass: "document-icon-color",
            handler: () => {}
          }
        ]
      })
      .present();
  }

  sendMessage(): void {
    if (this.messageId == null) {
      this.getMessageId(true).then(res => {
        if (res != null) {
          this.addToFb();
        }
      });
    }
    if (this.messageId != null) {
      this.addToFb();
    }
  }

  addToFb(): void {
    let sendBy: MessageSendBy = {
      id: this.userId
    };
    let saveData: MessageBox = {
      status: 1,
      id: this.toId,
      name: "Avatar",
      sendby: sendBy,
      sdate: new Date().getTime(),
      dtime: new Date().getTime(),
      rtime: new Date().getTime(),
      ismediacontent: false,
      message: this.messageTextBox,
      profileimage: "assets/img/avatar-profile-picture-default-i.jpg"
    };

    // this.messageList.push(saveData);
    this.fdb.database
      .ref("messages")
      .child(this.messageId)
      .push(saveData)
      .catch(err => {
        this.initLoad.loginToFirebase(this.userId);
      });
  }

  getMessageId(issave: boolean): Promise<any> {
    return new Promise((resolve, reject) => {
      let saveData = {
        fromId: this.userId,
        toId: this.toId,
        isactive: true,
        status: true,
        issave: issave
      };
      this.callchatMessage
        .saveCallChat(saveData)
        .then(res => {
          if (res["id"] != null) {
            this.messageId = res["id"];
            this.messageListener(this.messageId);
            resolve(this.messageId);
          } else {
            this.toast
              .create({
                message:
                  "Something went wrong, please try again after sometime.",
                duration: 2000
              })
              .present();
            resolve(null);
          }
        })
        .catch(err => {
          resolve(null);
          this.toast
            .create({
              message: "Something went wrong, please try again after sometime.",
              duration: 2000
            })
            .present();
        });
    });
  }

  ngOnInit(): void {
    this.toId = this.navParams.get("uItem").tuid;
    this.call.getValueByKey("userinfo").then(res => {
      this.userId = res.userId;
      this.getMessageId(false);
    });
    this.messageList = [];
  }

  messageListener(id: string) {
    let jsonData = null;
    this.fdb.database
      .ref("messages")
      .child(id)
      .on("child_added", res => {
        jsonData = res.toJSON();
        if (jsonData != null) {
          if (jsonData.message != null) {
            jsonData.message = jsonData.message.replace(/\n/g, "<br />");
          }
          this.messageList.push(jsonData);
          this.scrollToList();
        }
      });
  }

  userProfile(): void {}

  protected adjustTextarea(event: any): void {
    let textarea: any = event.target;
    textarea.style.overflow = "hidden";
    textarea.style.height = "auto";
    textarea.style.height = textarea.scrollHeight + "px";
    let hgth = textarea.style.height.replace(/px/g, "");
    if (parseInt(hgth) > 76) {
      textarea.style.height = "76px";
      textarea.style.overflow = "auto";
    }
    if (parseInt(hgth) == 46) {
      textarea.style.height = "32px";
    }

    if (textarea.value.length > 1) {
      this.textempty = false;
    } else {
      this.textempty = true;
    }
    return;
  }

  onHold(): void {
    console.log("okk");
  }

  ngAfterContentInit(): void {
    this.bgImage = "assets/img/speakers/bg.svg";

    this.chatboxbody.nativeElement.style.backgroundImage =
      "url(" + this.bgImage + ")";
    this.chatboxbody.nativeElement.style.backgroundRepeat = "no-repeat";
    this.chatboxbody.nativeElement.style.backgroundSize = "cover";

    this.chatboxbody.nativeElement.style.backgroundAttachment = "fixed";
  }

  scrollToList(): void {
    let scrollHeight = this.ionContent.getContentDimensions().scrollHeight + 30;
    this.ionContent.scrollTo(0, scrollHeight, 300);
  }
}
