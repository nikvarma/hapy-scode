export enum Operation {
  EqualTo,
  Contains,
  StartsWith,
  EndsWith,
  NotEqualTo,
  GreaterThan,
  GreaterThanOrEqualTo,
  LessThan,
  LessThanOrEqualTo
}