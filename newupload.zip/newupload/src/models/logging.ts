export class Logging {
    message: string;
    className: string;
    methodeName: string;
    extrainformation: string;
}