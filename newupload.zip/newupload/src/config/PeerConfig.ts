export const PeerConfig = {
    key: "da209363-b2e0-4fa5-a465-c206e41403b6"
}