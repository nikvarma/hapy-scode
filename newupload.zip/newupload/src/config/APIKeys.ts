export const APIKeys = {
    googleMap: "AIzaSyDyqaYCtR95AHGiN3C4EqEhQFYXM75bdfs"
}